import React from 'react'
import HalfSection from './Components/HalfSection/HalfSection'
import Category from './Components/Category/Category'
import BestSellerProduct from './Components/BestSellerProduct/BestSellerProduct'
import ArrivalCollection from './Components/ArrivalCollection/ArrivalCollection'
import CompanyLogo from './Components/CompanyLogo/CompanyLogo'

const App = () => {
  return (
    <div>
      <HalfSection />
      <Category />
      <BestSellerProduct />
      <div className='bg-black text-white text-center p-4 uppercase text-sm leading-8'>Take an extra 25% discount our favorite dress style. Use code: <span className='bg-[#fee300] text-black font-semibold px-4 py-1 rounded-full'>fw205</span></div>
      <ArrivalCollection />
      <CompanyLogo />
    </div>
  )
}

export default App