export const BestSellerProductData = [
    {
        id: 1,
        image : 'assets/bestSellerProductAssets/1.jpg',
        productName : "Textured sweater",
        price : "$189.00",
        delPrice : "$200.00"
    },
    {
        id: 2,
        image : 'assets/bestSellerProductAssets/2.jpg',
        productName : "Traveller shirt",
        price : "$350.00",
        delPrice : "$289.00"
    },
    {
        id: 3,
        image : 'assets/bestSellerProductAssets/3.jpg',
        productName : "Crewneck sweatshirt",
        price : "$220.00",
        delPrice : "$199.00"
    },
    {
        id: 4,
        image : 'assets/bestSellerProductAssets/4.jpg',
        productName : "Skinny trousers",
        price : "$300.00",
        delPrice : "$259.00"
    },
    {
        id: 5,
        image : 'assets/bestSellerProductAssets/5.jpg',
        productName : "Sleeve sweater",
        price : "$250.00",
        delPrice : "$239.00"
    },
    {
        id: 6,
        image : 'assets/bestSellerProductAssets/6.jpg',
        productName : "Pocket sweatshirt",
        price : "$200.00",
        delPrice : "$189.00"
    },
    {
        id: 7,
        image : 'assets/bestSellerProductAssets/7.jpg',
        productName : "Cotton sweater",
        price : "$150.00",
        delPrice : "$129.00"
    },
    {
        id: 8,
        image : 'assets/bestSellerProductAssets/8.jpg',
        productName : "Texture regular",
        price : "$170.00",
        delPrice : "$120.00"
    },
    {
        id: 9,
        image : 'assets/bestSellerProductAssets/9.jpg',
        productName : "Sequined dress",
        price : "$190.00",
        delPrice : "$150.00"
    },
    {
        id: 10,
        image : 'assets/bestSellerProductAssets/10.jpg',
        productName : "Bermuda shorts",
        price : "$120.00",
        delPrice : "$100.00"
    },
]