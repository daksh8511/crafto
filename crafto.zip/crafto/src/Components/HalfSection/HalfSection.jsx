import React from "react";
import { FiBox } from "react-icons/fi";
import { RxReload } from "react-icons/rx";
import { BsCreditCard2Back } from "react-icons/bs";
import { BsTelephone } from "react-icons/bs";

const HalfSection = () => {
  return (
    <div className="container grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4">

        {/* box  */}
      <div className="flex items-center gap-5">
        <FiBox className="text-3xl" />
        <div className="content">
          <h2 className="text-xl font-medium">Free shipping</h2>
          <h5 className="text-[16px] text-[#828282]">Free shipping on first order</h5>
        </div>
      </div>

      {/* reload box */}
      <div className="flex items-center gap-5">
        <RxReload className="text-3xl" />
        <div className="content">
          <h2 className="text-xl font-medium">15 days returns</h2>
          <h5 className="text-[16px] text-[#828282]">Moneyback guarantee</h5>
        </div>
      </div>

      {/* credit card box */}
      <div className="flex items-center gap-5">
        <BsCreditCard2Back className="text-3xl" />
        <div className="content">
          <h2 className="text-xl font-medium">Secure payment</h2>
          <h5 className="text-[16px] text-[#828282]">100% protected payment</h5>
        </div>
      </div>

      {/* telephone box */}
      <div className="flex items-center gap-5">
        <BsTelephone className="text-3xl" />
        <div className="content">
          <h2 className="text-xl font-medium">Online support</h2>
          <h5 className="text-[16px] text-[#828282]">24/7 days a week support</h5>
        </div>
      </div>
    </div>
  );
};

export default HalfSection;
